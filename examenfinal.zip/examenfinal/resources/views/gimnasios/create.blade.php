<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Crear Gimnasio</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>
        
      <div class="container">
        <form action="/gimnasios/store" method="POST">
            {{ csrf_field() }}
            <h1>Crear Gimnasio</h1>          
            <div class="form-group">
                 <label for="nombre">Nombre</label>
                 <input type="text" class="form-control" id="nombre" name="nombre" value="">
            </div>
            <div class="form-group">
            <input type="hidden" class="form-control input-sm" id="latitud" name="latitud">
            </div>
            <div class="form-group">
              <input type="hidden" class="form-control input-sm" id="longitud" name="longitud">
            </div>

            <div id="mapa" style="height: 400px"></div>

            <script>
                  function initMap() {
                      var centro = {lat: -12.074947 , lng: -77.079492};
             
                      var map = new google.maps.Map(document.getElementById('mapa'), {
                        zoom: 16,
                        center: centro
                      });
             
                      var marker = new google.maps.Marker({
                        position: centro,
                        map: map,
                        draggable:true,
                      });

                      var markerLatLng = marker.getPosition();
                          $('#latitud').val(markerLatLng.lat());
                          $('#longitud').val(markerLatLng.lng());

                    };
                      
            </script>
            
            <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDlsmx6_ehv1E-L69dAcXUMrKNMTEKO3u0&callback=initMap"
            async defer></script>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
      </div>
        
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>  
  </body>
</html>