<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Index</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>
        <div class="container">
        <a type="button" class="btn btn-primary" href="/administradores/index">
                <span class="glyphicon glyphicon-plus"></span>Log In
        </a>
        <div id="mapa" style="height: 600px"></div>

          <script>
                  function initMap() {
                      var ubicacion = {lat:-12.074927 , lng:-77.079285};
                      var map = new google.maps.Map(document.getElementById('mapa'), {
                        zoom: 14,
                        center: ubicacion
                      });
                      <?php $__currentLoopData = $gimnasios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gimnasio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              var ubicacionMarcador = {lat: <?php echo e($gimnasio->latitud); ?> , lng:<?php echo e($gimnasio->longitud); ?>};
                              var marker = new google.maps.Marker({
                                position: ubicacionMarcador,
                                map: map,
                                title: '<?php echo e($gimnasio->nombre); ?>, Lat:<?php echo e($gimnasio->latitud); ?>, Long:<?php echo e($gimnasio->longitud); ?>'
                              
                              });

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      var infoWindow = new google.maps.InfoWindow({map: map});
                      if (navigator.geolocation) {
                        navigator.geolocation.getCurrentPosition(function(position) {
                          var pos = {
                            lat: position.coords.latitude,
                            lng: position.coords.longitude
                          };
                          infoWindow.setPosition(pos);
                          infoWindow.setContent('Location found.');
                          //Esta funcion esta comentada ya que la ubicacion del usuario puede estar lejos de 
                          //los gimnasios, pero se puede quitar el comentario para mejor apreciacion
                          //map.setCenter(pos);
                        }, function() {
                          handleLocationError(true, infoWindow, map.getCenter());
                        });
                      } else {
                        // Browser doesn't support Geolocation
                        handleLocationError(false, infoWindow, map.getCenter());
                      }


                   };
          </script>
          <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDlsmx6_ehv1E-L69dAcXUMrKNMTEKO3u0&callback=initMap"
            async defer></script>
      </div>
      
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>  
  </body>
</html>