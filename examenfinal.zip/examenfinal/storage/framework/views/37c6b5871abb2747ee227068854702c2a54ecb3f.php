<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vista Administrador</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  </head>
  <body>
    <nav class="navbar-form navbar-right">
                   <div class="container-fluid">
                    <form action="/" method="GET">
                      <button type="submit" class="btn btn-primary">
                        <span class="glyphicon glyphicon-plus"></span> Cerrar Sesion
                      </button>                     
                    </form>
                   </div>
    </nav> 
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 col-md">
                <h1>Listado de Gimnasios</h1>
                <table class="table table-bordered">
                  <thead>
                      <tr class="bg-primary">
                          <th>id</th>
                          <th>Nombre</th>
                          <th>Latitud</th>
                          <th>Longitud</th>
                          <th>
                            <a type="button" class="btn btn-primary" href="/gimnasios/create"><span class="glyphicon glyphicon-plus"></span>Registrar Gimnasio</a>
                          </th>
                      </tr>
                  </thead>
                  <tbody>
                   <?php $__currentLoopData = $gimnasios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gimnasio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($gimnasio->id); ?></td>
                      <td><?php echo e($gimnasio->nombre); ?></td>  
                      <td><?php echo e($gimnasio->latitud); ?></td>
                      <td><?php echo e($gimnasio->longitud); ?></td>
                      <td><form action="/gimnasios/edit/<?php echo e($gimnasio->id); ?>" method="GET">
                        <button type="submit" class="btn btn-primary">Editar</button>
                      </form></td>
                      <td><form action="/gimnasios/destroy/<?php echo e($gimnasio->id); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
                        <button type="submit" class="btn btn-primary">Borrar</button>
                      </form></td>
                    </tr>             
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>                
            </div>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>  
  </body>
</html>