<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gimnasio extends Model
{
    protected $primaryKey = 'id';
    public $timestamps = false;
}
