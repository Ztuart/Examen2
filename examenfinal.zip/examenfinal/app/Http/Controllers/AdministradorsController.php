<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Administrador;
use App\Gimnasio;


class AdministradorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('administradores.index');
    }



    public function login(Request $request)
    {
        $gimnasios = Gimnasio::all();
        $correo = $request->input('correo');
        $password = $request->input('password');
        $administrador = DB::table('administradors')->where([['correo', '=', $correo],['password', '=', $password],])->get();
        if($administrador == '[]'){
            return view('administradores.index');
        }else{
            return view('administradores.modify', compact('gimnasios'));
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

}
