<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Administrador;
use App\Gimnasio;

class GimnasiosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $gimnasios = Gimnasio::all();
        return view('gimnasios.index', compact('gimnasios'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return  view('gimnasios.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $gimnasio = new Gimnasio;
        $gimnasio->nombre = $request->input('nombre');
        $gimnasio->latitud = $request->input('latitud');
        $gimnasio->longitud = $request->input('longitud');
        $gimnasio->save();

        return redirect('/administradores/modify');
    }

  
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $gimnasio = Gimnasio::findOrFail($id);
        return view('gimnasios.edit', compact('gimnasio'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $gimnasio = Gimnasio::findOrFail($id);
        $gimnasio->nombre = $request->input('nombre');
        $gimnasio->latitud = $request->input('latitud');
        $gimnasio->longitud = $request->input('longitud');
        $equipo->save();
        return redirect('/administradores/modify');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $gimnasio = Gimnasio::findOrFail($id);
        $gimnasio->delete();
        return redirect('/administradores/modify');
    }
}
