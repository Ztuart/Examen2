<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'GimnasiosController@index');
Route::get('/administradores/index', 'AdministradorsController@index');
Route::get('/gimnasios/edit/{id}', 'GimnasiosController@edit');
Route::get('/gimnasios/create', 'GimnasiosController@create');
Route::get('/administradores/modify', function(){
		$gimnasios = App\Gimnasio::all();
		return view('administradores.modify', compact('gimnasios'));
});


Route::post('/administradores/modify', 'AdministradorsController@login');
Route::post('/gimnasios/update/{id}', 'GimnasiosController@update');
Route::post('/gimnasios/destroy/{id}', 'GimnasiosController@destroy');
Route::post('/gimnasios/store', 'GimnasiosController@store');
